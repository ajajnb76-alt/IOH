# HOI4: Mobile Command 1936 — сборка APK (без GitHub)

Игра полностью офлайн. Сборщик — один Python-скрипт `build_apk.py`, только стандартная библиотека.
Он сам находит или скачивает JDK 17, Android SDK и Gradle (официальные сервера Google, Gradle и Adoptium) и кэширует их в `~/.hoi4_apk_tools`.

## На компьютере (Windows / Linux / macOS)
1. Установите Python 3.8+ (python.org).
2. Распакуйте архив, откройте папку.
3. Windows: двойной клик по `build_windows.bat`. Linux/Mac: `python3 build_apk.py`.
4. Готовый `HOI4_Mobile_Command.apk` появится в этой же папке. Первая сборка 5–15 минут, нужен интернет (~600 МБ загрузок).

## На телефоне (Termux, экспериментально)
1. Установите Termux с F-Droid (версия из Google Play устарела).
2. `pkg install python` → `termux-setup-storage` (разрешить доступ к файлам).
3. Распакуйте архив в `~/hoi4` и выполните `cd ~/hoi4/hoi4_mobile_android_apk_project && python build_apk.py`.
4. Скрипт сам поставит JDK и aapt2, соберёт APK, положит копию в «Загрузки» и откроет установщик. Нужно ~3 ГБ свободного места и 4+ ГБ ОЗУ.

## Своя версия игры
`python build_apk.py --game новая_игра.html` — HTML подставится внутрь APK. Или положите файл `game.html` рядом со скриптом.
`python build_apk.py --check` — только проверить проект.

## Android Studio
Откройте папку проекта → Build → Build APK(s).
