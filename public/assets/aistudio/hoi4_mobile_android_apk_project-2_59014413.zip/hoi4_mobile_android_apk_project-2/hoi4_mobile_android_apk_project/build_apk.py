#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Автосборщик APK для HOI4: Mobile Command. Только стандартный Python 3.8+, без GitHub и сторонних сервисов.
Запуск:   python build_apk.py                     (Windows: python, Linux/Mac: python3, Termux: python)
          python build_apk.py --game новая.html    (подставить свою версию игры)
          python build_apk.py --check              (только проверка проекта, без сборки)
Сам найдёт или скачает: JDK 17, Android SDK (официально с dl.google.com), Gradle (services.gradle.org).
Всё кэшируется в ~/.hoi4_apk_tools — повторные сборки быстрые.
"""
import os, sys, re, shutil, subprocess, platform, zipfile, tarfile, argparse, urllib.request, glob, stat

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(os.path.expanduser("~"), ".hoi4_apk_tools")
IS_WIN = os.name == "nt"
IS_TERMUX = "TERMUX_VERSION" in os.environ or "com.termux" in sys.prefix
GRADLE_VER, CT_REV = "8.7", "11076708"
OUT_NAME = "HOI4_Mobile_Command.apk"

def say(m): print("\n\033[1;33m[HOI4]\033[0m " + m, flush=True)
def die(m): print("\n\033[1;31m[ОШИБКА]\033[0m " + m); sys.exit(1)

def run(cmd, env=None, cwd=None, inp=None, check=True):
    r = subprocess.run(cmd, env=env, cwd=cwd, input=inp, text=bool(inp), shell=IS_WIN and isinstance(cmd, str))
    if check and r.returncode: die("Команда завершилась с ошибкой: %s" % (cmd if isinstance(cmd, str) else " ".join(cmd)))
    return r

def download(url, dest):
    if os.path.exists(dest) and os.path.getsize(dest) > 0: return dest
    say("Скачиваю " + url); os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0); got = 0
        while True:
            b = r.read(1 << 16)
            if not b: break
            f.write(b); got += len(b)
            if total: print("\r   %d%% (%d МБ)" % (got * 100 // total, got >> 20), end="", flush=True)
    print(); os.replace(tmp, dest); return dest

def extract(archive, dest):
    os.makedirs(dest, exist_ok=True)
    if archive.endswith(".zip"):
        with zipfile.ZipFile(archive) as z:
            for i in z.infolist():
                z.extract(i, dest)
                mode = (i.external_attr >> 16) & 0o777
                if mode: os.chmod(os.path.join(dest, i.filename), mode | stat.S_IWUSR)
    else:
        with tarfile.open(archive) as t: t.extractall(dest)

def java_ok(java):
    try:
        out = subprocess.run([java, "-version"], capture_output=True, text=True).stderr
        m = re.search(r'version "(\d+)', out); return bool(m) and 17 <= int(m.group(1)) <= 21
    except Exception: return False

def ensure_java():
    jh = os.environ.get("JAVA_HOME")
    exe = "java.exe" if IS_WIN else "java"
    if jh and java_ok(os.path.join(jh, "bin", exe)): return jh
    sysjava = shutil.which("java")
    if sysjava and java_ok(sysjava):
        return os.path.dirname(os.path.dirname(os.path.realpath(sysjava)))
    if IS_TERMUX:
        say("Ставлю JDK 17 через pkg (Termux)")
        run(["pkg", "install", "-y", "openjdk-17"])
        jh = os.path.join(os.environ.get("PREFIX", "/data/data/com.termux/files/usr"), "lib", "jvm", "java-17-openjdk")
        if java_ok(os.path.join(jh, "bin", "java")): return jh
        die("Не удалось поставить JDK. Выполните вручную: pkg install openjdk-17")
    osn = {"Windows": "windows", "Linux": "linux", "Darwin": "mac"}.get(platform.system())
    m = platform.machine().lower(); arch = "aarch64" if m in ("arm64", "aarch64") else "x64"
    if not osn: die("Неизвестная ОС: " + platform.system())
    ext = "zip" if IS_WIN else "tar.gz"
    url = "https://api.adoptium.net/v3/binary/latest/17/ga/%s/%s/jdk/hotspot/normal/eclipse" % (osn, arch)
    arc = download(url, os.path.join(TOOLS, "jdk17." + ext))
    d = os.path.join(TOOLS, "jdk17")
    if not os.path.isdir(d): extract(arc, d)
    for c in glob.glob(os.path.join(d, "*")):
        for home in (c, os.path.join(c, "Contents", "Home")):
            if os.path.exists(os.path.join(home, "bin", exe)):
                if not IS_WIN:
                    for f in glob.glob(os.path.join(home, "bin", "*")): os.chmod(f, 0o755)
                return home
    die("JDK скачан, но не найден внутри архива.")

def ensure_sdk(env):
    sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT") or os.path.join(TOOLS, "android-sdk")
    if os.path.isdir(os.path.join(sdk, "platforms", "android-34")) and glob.glob(os.path.join(sdk, "build-tools", "34*")): return sdk
    osn = "win" if IS_WIN else ("mac" if platform.system() == "Darwin" else "linux")
    arc = download("https://dl.google.com/android/repository/commandlinetools-%s-%s_latest.zip" % (osn, CT_REV), os.path.join(TOOLS, "cmdline-tools.zip"))
    tmp = os.path.join(TOOLS, "ct_tmp"); shutil.rmtree(tmp, ignore_errors=True); extract(arc, tmp)
    latest = os.path.join(sdk, "cmdline-tools", "latest")
    if not os.path.isdir(latest):
        os.makedirs(os.path.dirname(latest), exist_ok=True); shutil.move(os.path.join(tmp, "cmdline-tools"), latest)
    sm = os.path.join(latest, "bin", "sdkmanager.bat" if IS_WIN else "sdkmanager")
    if not IS_WIN:
        for f in glob.glob(os.path.join(latest, "bin", "*")): os.chmod(f, 0o755)
    e = dict(env, ANDROID_HOME=sdk, ANDROID_SDK_ROOT=sdk)
    say("Принимаю лицензии и ставлю Android SDK 34 (около 100–200 МБ)")
    run([sm, "--sdk_root=" + sdk, "--licenses"], env=e, inp="y\n" * 60, check=False)
    run([sm, "--sdk_root=" + sdk, "platforms;android-34", "build-tools;34.0.0"], env=e, inp="y\n" * 10)
    return sdk

def ensure_gradle():
    d = os.path.join(TOOLS, "gradle-" + GRADLE_VER); exe = os.path.join(d, "bin", "gradle.bat" if IS_WIN else "gradle")
    if os.path.exists(exe): return exe
    arc = download("https://services.gradle.org/distributions/gradle-%s-bin.zip" % GRADLE_VER, os.path.join(TOOLS, "gradle.zip"))
    extract(arc, TOOLS)
    if not IS_WIN: os.chmod(exe, 0o755)
    return exe

def check_project():
    need = ["settings.gradle", "build.gradle", "app/build.gradle", "app/src/main/AndroidManifest.xml", "app/src/main/assets/index.html"]
    miss = [n for n in need if not os.path.exists(os.path.join(HERE, n))]
    if miss: die("В проекте не хватает файлов: " + ", ".join(miss))

def main():
    ap = argparse.ArgumentParser(description="Автосборка APK HOI4 Mobile Command")
    ap.add_argument("--game", help="путь к своему .html, который заменит игру внутри APK")
    ap.add_argument("--check", action="store_true", help="только проверить проект")
    ap.add_argument("--release-name", default=OUT_NAME)
    a = ap.parse_args()
    check_project()
    game = a.game or (os.path.join(HERE, "game.html") if os.path.exists(os.path.join(HERE, "game.html")) else None)
    if game:
        if not os.path.exists(game): die("Файл игры не найден: " + game)
        shutil.copyfile(game, os.path.join(HERE, "app", "src", "main", "assets", "index.html")); say("Игра обновлена из " + game)
    if a.check: say("Проект в порядке."); return
    say("Платформа: %s %s%s" % (platform.system(), platform.machine(), " (Termux)" if IS_TERMUX else ""))
    jh = ensure_java(); env = dict(os.environ, JAVA_HOME=jh)
    env["PATH"] = os.path.join(jh, "bin") + os.pathsep + env.get("PATH", "")
    sdk = ensure_sdk(env); env.update(ANDROID_HOME=sdk, ANDROID_SDK_ROOT=sdk)
    with open(os.path.join(HERE, "local.properties"), "w") as f: f.write("sdk.dir=%s\n" % sdk.replace("\\", "/"))
    if IS_TERMUX:   # aapt2 из Maven — x86, на телефоне он не запустится, берём родной
        if not shutil.which("aapt2"): run(["pkg", "install", "-y", "aapt2"])
        gp = os.path.join(HERE, "gradle.properties"); t = open(gp).read() if os.path.exists(gp) else ""
        if "aapt2FromMavenOverride" not in t: open(gp, "a").write("\nandroid.aapt2FromMavenOverride=%s\n" % shutil.which("aapt2"))
    gradle = ensure_gradle()
    say("Собираю APK (первый раз 5–15 минут, дальше быстро)")
    run([gradle, "assembleDebug", "--no-daemon", "--console=plain"], env=env, cwd=HERE)
    src = os.path.join(HERE, "app", "build", "outputs", "apk", "debug", "app-debug.apk")
    if not os.path.exists(src): die("Gradle отработал, но APK не найден.")
    out = os.path.join(HERE, a.release_name); shutil.copyfile(src, out)
    dl = os.path.expanduser("~/storage/downloads")
    if os.path.isdir(dl): shutil.copyfile(src, os.path.join(dl, a.release_name)); say("Копия в папке «Загрузки»")
    say("ГОТОВО! APK: " + out)
    if IS_TERMUX and shutil.which("termux-open"): run(["termux-open", out], check=False)

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: die("Прервано.")
